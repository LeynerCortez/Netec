package co.com.bancolombia.infrastructure.db;

import co.com.bancolombia.domain.Cliente;
import co.com.bancolombia.domain.ServicioClientes;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.TreeSet;

public class DAOClientes implements ServicioClientes {
    private String url="jdbc:mysql://localhost:3306/bancaelectronica";
    private String usuario="root";
    private String password="root";

    private DriverManager driver;

    private Connection conexion;
    private Statement sentencia;
    private String sql;
    private ResultSet resultado;
    private int renglones;


    public DAOClientes() {
        url="jdbc:mysql://localhost:3306/bancaelectronica";
        usuario="root";
        password="root";
        try {
            this.conexion = DriverManager.getConnection(url,usuario,password);
            this.sentencia = this.conexion.createStatement();
            System.out.println("Se conecto de manera exitosa");
        } catch (SQLException e) {
            System.out.println("problema de conexion con la BD:"+e.getMessage());
        }
    }

    public DAOClientes(String url, String usuario, String password) {
        this.url = url;
        this.usuario = usuario;
        this.password = password;
        try {
            this.conexion = DriverManager.getConnection(url,usuario,password);
            sentencia = this.conexion.createStatement();
            System.out.println("Se conecto de manera exitosa a la Banca");
        } catch (SQLException e) {
            System.out.println("Hubo un problema de conexion con la BD:"+e.getMessage());
        }

    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getUsuario() {
        return usuario;
    }

    public void setUsuario(String usuario) {
        this.usuario = usuario;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    @Override
    public boolean agregarCliente(Cliente cliente) {
        sql="INSERT INTO CLIENTES (numero,nombre,domicilio) VALUES ("+cliente.getNumero()+",'"+cliente.getNombre()+"','"+cliente.getDomicilio().getEstado()+"');";
        System.out.println("SQL: "+sql);
        try {
            PreparedStatement sentencia = conexion.prepareStatement(sql);
            sentencia.execute();
            return true;
        } catch (SQLException e) {
            System.out.println("Hubo problemas al Eliminar al Cliente");
            System.out.println("Excepcion: "+e.getMessage());
        }
        return false;
    }


    @Override
    public boolean eliminarCliente(int numero) {
        sql="DELETE FROM CLIENTES where numero = "+numero+";";
        System.out.println("SQL: "+sql);
        try {
            PreparedStatement sentencia = conexion.prepareStatement(sql);
            sentencia.execute();
            return true;
        } catch (SQLException e) {
            System.out.println("Hubo problemas al agregar al Cliente");
            System.out.println("Excepcion: "+e.getMessage());
        }
        return false;
    }

    @Override
    public Cliente consultarCliente(int numero) {
        sql="SELECT * FROM CLIENTES where numero = "+numero+";";
        try {
            resultado = sentencia.executeQuery(sql);
            while (resultado.next()){
                System.out.println("Id: "+resultado.getInt("numero"));
                System.out.println("Nombre: "+ resultado.getString("nombre"));
                System.out.println("Domicilio: "+resultado.getString("domicilio"));
                return Cliente.builder()
                        .numero(resultado.getInt("numero"))
                        .nombre(resultado.getString("nombre"))
                        .build();
            }
        } catch (SQLException e) {
            System.out.println("Se genero una excepcion al hacer el SELECT");
            System.out.println("Mensaje: "+e.getMessage());
            return null;
        }
        return null;
    }

    @Override
    public TreeSet<Cliente> obtenerClientes() {
        sql="SELECT * FROM CLIENTES;";
        TreeSet<Cliente> clientes = new TreeSet<>();
        try {
            resultado = sentencia.executeQuery(sql);
            while (resultado.next()){
                System.out.println("Id: "+resultado.getInt("numero"));
                System.out.println("Nombre: "+ resultado.getString("nombre"));
                System.out.println("Domicilio: "+resultado.getString("domicilio"));
                clientes.add(Cliente.builder()
                        .numero(resultado.getInt("numero"))
                        .nombre(resultado.getString("nombre"))
                        .build());
            }
            return clientes;
        } catch (SQLException e) {
            System.out.println("Se genero una excepcion al hacer el SELECT");
            System.out.println("Mensaje: "+e.getMessage());
            return null;
        }
    }

    @Override
    public Cliente buscarClientePorRFC(String rfc) {
        sql="SELECT * FROM CLIENTES where rfc = "+rfc+";";
        try {
            resultado = sentencia.executeQuery(sql);
            while (resultado.next()){
                System.out.println("Id: "+resultado.getInt("numero"));
                System.out.println("Nombre: "+ resultado.getString("nombre"));
                System.out.println("Domicilio: "+resultado.getString("domicilio"));
                return Cliente.builder()
                        .numero(resultado.getInt("numero"))
                        .nombre(resultado.getString("nombre"))
                        .build();
            }
        } catch (SQLException e) {
            System.out.println("Se genero una excepcion al hacer el SELECT");
            System.out.println("Mensaje: "+e.getMessage());
            return null;
        }
        return null;
    }

    public void cerrarConexion() throws SQLException {
        conexion.close();
    }
}
