package co.com.bancolombia.domain;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@NoArgsConstructor
@AllArgsConstructor
@Data
@SuperBuilder
public abstract class Cuenta implements Comparable<Cuenta> {
    private int numero;
    private String fechaApertura;
    private double saldo;
    private String fechaCancelacion;

    public void abono(double cantidad){
        this.saldo += cantidad;
        System.out.println("Se realizo un abono por: = " + cantidad + "su nuevo saldo es: "+ saldo);
    }
    public void retiro(double cantidad){
        if (cantidad<=this.saldo){
            this.saldo-=cantidad;
            System.out.println("Se realizo un retiro por: = " + cantidad + "su nuevo saldo es: "+ saldo);
        } else {
            System.out.println("Saldo Insuficiente, Saldo actual es: "+ saldo);

        }
    }
    @Override
    public abstract int compareTo(Cuenta o);

    /*public int getNumero() {
        return numero;
    }

    public void setNumero(int numero) {
        this.numero = numero;
    }

    public String getFechaApertura() {
        return fechaApertura;
    }

    public void setFechaApertura(String fechaApertura) {
        this.fechaApertura = fechaApertura;
    }

    public double getSaldo() {
        return saldo;
    }

    public void setSaldo(double saldo) {
        this.saldo = saldo;
    }

    public String getFechaCancelacion() {
        return fechaCancelacion;
    }

    public void setFechaCancelacion(String fechaCancelacion) {
        this.fechaCancelacion = fechaCancelacion;
    }

    @Override
    public String toString() {
        return "Cuenta{" +
                "numero=" + numero +
                ", fechaApertura='" + fechaApertura + '\'' +
                ", saldo=" + saldo +
                ", fechaCancelacion='" + fechaCancelacion + '\'' +
                '}';
    }

    public Cuenta(int numero, String fechaApertura, double saldo) {
        this.numero = numero;
        this.fechaApertura = fechaApertura;
        this.saldo = saldo;
    }*/
}
