package co.com.bancolombia.infrastructure.db;

import co.com.bancolombia.domain.Cliente;
import co.com.bancolombia.domain.Cuenta;
import co.com.bancolombia.domain.ServicioClientes;
import co.com.bancolombia.domain.ServicioCuentas;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.TreeSet;

public class DAOCuentas implements ServicioCuentas {
    private String url="jdbc:mysql://localhost:3306/bancaelectronica";
    private String usuario="root";
    private String password="root";

    private DriverManager driver;

    private Connection conexion;
    private Statement sentencia;
    private String sql;
    private ResultSet resultado;
    private int renglones;


    public DAOCuentas() {
         url="jdbc:mysql://localhost:3306/banca";
         usuario="root";
         password="abc123";
        try {
            this.conexion = DriverManager.getConnection(url,usuario,password);
            this.sentencia = this.conexion.createStatement();
            System.out.println("Se conecto de manera exitosa a la Banca");
        } catch (SQLException e) {
            System.out.println("Hubo un problema de conexion con la BD:"+e.getMessage());
        }
    }

    public DAOCuentas(String url, String usuario, String password) {
        this.url = url;
        this.usuario = usuario;
        this.password = password;
        try {
            this.conexion = DriverManager.getConnection(url,usuario,password);
            sentencia = this.conexion.createStatement();
            System.out.println("Se conecto de manera exitosa a la Banca");
        } catch (SQLException e) {
            System.out.println("Hubo un problema de conexion con la BD:"+e.getMessage());
        }

    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getUsuario() {
        return usuario;
    }

    public void setUsuario(String usuario) {
        this.usuario = usuario;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }


    public void cerrarConexion() throws SQLException {
        conexion.close();
    }

    @Override
    public boolean agregarCuenta(Cuenta cuenta) {
        sql="INSERT INTO CUENTA (numero,fechaapertura,saldo) VALUES " +
                "("+cuenta.getNumero()+",'"+cuenta.getFechaApertura()+"','"+cuenta.getSaldo()+"');";
        System.out.println("SQL: "+sql);
        try {
            PreparedStatement sentencia = conexion.prepareStatement(sql);
            sentencia.execute();
            return true;
        } catch (SQLException e) {
            System.out.println("Hubo problemas al agregar al Cliente");
            System.out.println("Excepcion: "+e.getMessage());
        }
        return false;
    }

    @Override
    public boolean cancelarCuenta(int numero) {
        sql="UPDATE CUENTA set fechacancelacion = current_date where numero = "+numero+";";
        System.out.println("SQL: "+sql);
        try {
            PreparedStatement sentencia = conexion.prepareStatement(sql);
            sentencia.execute();
            return true;
        } catch (SQLException e) {
            System.out.println("Hubo problemas al modificar cuenta");
            System.out.println("Excepcion: "+e.getMessage());
        }
        return false;
    }

    @Override
    public void abonarCuenta(int numero, double abono) {
        sql="UPDATE CUENTA set saldo += "+abono+" where numero = "+numero+";";
        System.out.println("SQL: "+sql);
        try {
            PreparedStatement sentencia = conexion.prepareStatement(sql);
            sentencia.execute();
        } catch (SQLException e) {
            System.out.println("Hubo problemas al modificar cuenta");
            System.out.println("Excepcion: "+e.getMessage());
        }
    }

    @Override
    public void retirar(int numero, double retiro) {
        sql="UPDATE CUENTA set saldo -= "+retiro+" where numero = "+numero+";";
        System.out.println("SQL: "+sql);
        try {
            PreparedStatement sentencia = conexion.prepareStatement(sql);
            sentencia.execute();
        } catch (SQLException e) {
            System.out.println("Hubo problemas al modificar cuenta");
            System.out.println("Excepcion: "+e.getMessage());
        }
    }

    @Override
    public ArrayList<Cuenta> obtenerCuentas() {
        /*sql="SELECT * FROM CUENTAS;";
        ArrayList<Cuenta> cuentas = new ArrayList<>();
        try {
            resultado = sentencia.executeQuery(sql);
            while (resultado.next()){
                var Cuenta cuenta = new Cuenta();
                System.out.println("Id: "+resultado.getInt("numero"));
                System.out.println("Nombre: "+ resultado.getString("nombre"));
                System.out.println("Domicilio: "+resultado.getString("domicilio"));
                cuentas.add();
            }
            return clientes;
        } catch (SQLException e) {
            System.out.println("Se genero una excepcion al hacer el SELECT");
            System.out.println("Mensaje: "+e.getMessage());
            return null;
        }*/
        return null;
    }
}
