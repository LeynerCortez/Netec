package co.com.bancolombia.domain;

import lombok.Builder;
import lombok.Data;

import java.sql.Date;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;

@Data
@Builder(toBuilder = true)
public class Cliente implements Comparable<Cliente>, ServicioCuentas {
    private int numero;
    private String nombre;
    private Domicilio domicilio;
    private String rfc;
    private String telefono;
    private ArrayList<Cuenta> cuentas;
    private String fechaNacimiento;


    @Override
    public boolean agregarCuenta(Cuenta cuenta) {
        cuentas.add(cuenta);
        System.out.println("cuenta agregada= " + cuenta);
        return true;
    }

    @Override
    public boolean cancelarCuenta(int numero) {
        DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");
        LocalDateTime now = LocalDateTime.now();
        Cuenta cuenta = buscarCuentaXNumero(numero);
        if (cuenta!=null) {
            cuenta.setFechaCancelacion(dtf.format(now));
            cuentas.remove(cuenta);
            cuentas.add(cuenta);
            System.out.println("Cuenta con número: "+numero+" Cancelada");
            System.out.println("cuenta = " + cuenta);
            return true;
        }
        System.out.println("Cuenta con número: "+numero+" No Existe");
        return false;
    }

    @Override
    public void abonarCuenta(int numero, double abono) {
        Cuenta cuenta = buscarCuentaXNumero(numero);
        cuenta.setSaldo(cuenta.getSaldo()+abono);
        cuentas.remove(cuenta);
        cuentas.add(cuenta);
        System.out.println("abono realizado en cuenta = " + cuenta);
    }

    @Override
    public void retirar(int numero, double retiro) {
        Cuenta cuenta = buscarCuentaXNumero(numero);
        if (cuenta.getSaldo()<=retiro){
            cuenta.setSaldo(cuenta.getSaldo()-retiro);
            cuentas.remove(cuenta);
            cuentas.add(cuenta);
            System.out.println("retiro realizado en cuenta = " + cuenta);
        } else {
            System.out.println("cuenta sin saldo = " + cuenta);
        }

    }

    @Override
    public ArrayList<Cuenta> obtenerCuentas() {
        return cuentas;
    }

    @Override
    public int compareTo(Cliente o) {
        return Integer.valueOf(this.numero).compareTo(o.getNumero());
    }

    public Cuenta buscarCuentaXNumero(int numero){
        return cuentas.stream()
                .filter(cuenta -> cuenta.getNumero()==numero)
                .findFirst().get();
        /*for (Cuenta cuentasList:cuentas){
            if (cuentasList.getNumero()==numero){
                return cuentasList;
            }
        }
        return null;*/
    }
}
