package co.com.bancolombia.domain;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.ToString;
import lombok.experimental.SuperBuilder;

@Data
@NoArgsConstructor
@SuperBuilder
@ToString(callSuper = true)
@EqualsAndHashCode(callSuper=false)
public class CuentaDeAhorro extends Cuenta{
    private double tasaInteresMensual;

    @Override
    public int compareTo(Cuenta o) {
        return Integer.valueOf((int)super.getSaldo()).compareTo((int)o.getSaldo());
    }

    /*public CuentaDeAhorro(int numero, String fechaApertura, double saldo, double tasaInteresMensual) {
        super(numero, fechaApertura, saldo);
        this.tasaInteresMensual = tasaInteresMensual;
    }

    public double getTasaInteresMensual() {
        return tasaInteresMensual;
    }

    public void setTasaInteresMensual(double tasaInteresMensual) {
        this.tasaInteresMensual = tasaInteresMensual;
    }

    @Override
    public String toString() {

        return super.toString()+" CuentaDeAhorro{" +
                "tasaInteresMensual=" + tasaInteresMensual +
                '}';
    }*/
}
