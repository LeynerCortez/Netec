package co.com.bancolombia.domain;


import lombok.Builder;
import lombok.Data;

import java.util.ArrayList;
import java.util.TreeSet;

@Data
@Builder(toBuilder = true)
public class Banco implements ServicioClientes{

    private String nombre;
    private Domicilio domicilio;
    private String rfc;
    private String telefono;
    private TreeSet<Cliente> clientes;

    @Override
    public boolean agregarCliente(Cliente cliente) {
        if (clientes.contains(cliente)){
            return false;
        } else {
            this.clientes.add(cliente);
            return true;
        }
    }

    @Override
    public boolean eliminarCliente(int numero) {
        Cliente cliente = this.consultarCliente(numero);
        if (cliente!=null){
            clientes.remove(cliente);
            System.out.println("Se dio de baja al cliente número = " + numero);
            return true;
        } else {
            return true;
        }
    }

    @Override
    public Cliente consultarCliente(int numero) {
        for (Cliente clienteList:clientes){
            if(clienteList.getNumero()==numero){
                System.out.println("Se encontro el cliente número = " + numero);
                return clienteList;
            }
        }
        System.out.println("No se encontro el cliente número = " + numero);
        return null;
    }

    @Override
    public TreeSet<Cliente> obtenerClientes() {
        return clientes;
    }

    @Override
    public Cliente buscarClientePorRFC(String rfc) {
        for (Cliente clienteList:clientes){
            if(clienteList.getRfc().equals(rfc)){
                System.out.println("Se encontro el cliente con rfc = " + rfc);
                return clienteList;
            }
        }
        System.out.println("No se encontro el cliente con rfc = " + rfc);
        return null;
    }

    public void listarClientes() {
        for (Cliente clienteList:clientes){
            System.out.println("clienteList = " + clienteList);
        }
    }
}
