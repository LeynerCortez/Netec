package co.com.bancolombia.domain;

import lombok.Builder;
import lombok.Data;

@Data
@Builder(toBuilder = true)
public class Domicilio {
    private String calle;
    private int numero;
    private String colonia;
    private String estado;
    private int codigoPostal;
}
