package co.com.bancolombia;

import co.com.bancolombia.domain.Banco;
import co.com.bancolombia.domain.Cliente;
import co.com.bancolombia.domain.Cuenta;
import co.com.bancolombia.domain.CuentaDeAhorro;
import co.com.bancolombia.domain.Domicilio;

import java.util.ArrayList;
import java.util.TreeSet;

public class Main {
    public static void main(String[] args) {
        /*Cuenta.builder()
                .numero()
                .build();*/

        //CuentaDeAhorro cuentaAhorroC1 = new CuentaDeAhorro(123, "2024-03-01", 1000, 1.2);

        //System.out.println("cuentaAhorroC1 = " + cuentaAhorroC1);

        //Creo el Banco
        var bancolombia = Banco.builder()
                .nombre("Bancolombia")
                .telefono("5109000")
                .domicilio(Domicilio.builder()
                        .calle("Carrera 48 # 26 - 85")
                        .numero(1)
                        .colonia("Industriales")
                        .estado("Antioquia")
                        .codigoPostal(50001)
                        .build())
                .rfc("123")
                .clientes(new TreeSet<>())
                .build();

        //Creo los clientes
        var pepe = Cliente.builder()
                .nombre("Pepe")
                .numero(968)
                .domicilio(Domicilio.builder()
                        .calle("Carrera 22 # 41a - 85")
                        .numero(1)
                        .colonia("Medellín")
                        .estado("Antioquia")
                        .codigoPostal(50001)
                        .build())
                .rfc("456")
                .fechaNacimiento("10-02-1992")
                .cuentas(new ArrayList<>())
                .build();

        var ana = Cliente.builder()
                .nombre("Ana")
                .numero(250)
                .domicilio(Domicilio.builder()
                        .calle("Carrera 21 # 85a - 85")
                        .numero(1)
                        .colonia("Medellín")
                        .estado("Antioquia")
                        .codigoPostal(50001)
                        .build())
                .rfc("789")
                .fechaNacimiento("10-02-1992")
                .cuentas(new ArrayList<>())
                .build();

        //Creo las Cuentas
        var cuentaAHPepe = CuentaDeAhorro.builder()
                .numero(123)
                .fechaApertura("2024-03-01")
                .saldo(1000)
                .tasaInteresMensual(1.2)
                .build();

        var cuentaCHPepe = CuentaDeAhorro.builder()
                .numero(987)
                .fechaApertura("2024-03-01")
                .saldo(1000)
                .tasaInteresMensual(1.2)
                .build();

        var cuentaAHAna = CuentaDeAhorro.builder()
                .numero(354)
                .fechaApertura("2024-03-01")
                .saldo(1000)
                .tasaInteresMensual(1.2)
                .build();

        var cuentaCHAna = CuentaDeAhorro.builder()
                .numero(2587)
                .fechaApertura("2024-03-01")
                .saldo(1000)
                .tasaInteresMensual(1.2)
                .build();

        //Amarro cuentas a Clientes
        pepe.agregarCuenta(cuentaAHPepe);
        pepe.agregarCuenta(cuentaCHPepe);
        ana.agregarCuenta(cuentaAHAna);
        ana.agregarCuenta(cuentaCHAna);

        //Amarro Clientes a Banco
        bancolombia.agregarCliente(pepe);
        bancolombia.agregarCliente(ana);

        //Cancelo Cuentas de Ahorro


        System.out.println(bancolombia.getClientes());

        ana.cancelarCuenta(354);

        System.out.println("ana = " + ana);


    }
}